<?php
// Text
$_['text_oprice']       = '<span style="color:green">Price with options x Qty: </span>';
?>