<?php
// Heading
$_['heading_title']     = 'Reporte de Clientes en Linea';

// Text
$_['text_guest']        = 'Invitado';

// Column
$_['column_ip']         = 'IP';
$_['column_customer']   = 'Cliente';
$_['column_url']        = 'Ultima página visitada';
$_['column_referer']    = 'Remitir';
$_['column_date_added'] = 'Ultimo Click';
$_['column_action']     = 'Acción';
?>
