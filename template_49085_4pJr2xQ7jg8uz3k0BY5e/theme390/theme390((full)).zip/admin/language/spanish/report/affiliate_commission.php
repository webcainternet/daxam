<?php
// Heading
$_['heading_title']     = 'Informe de la Comisión de Afiliados';

// Column
$_['column_affiliate']  = 'Nombre del Afiliado';
$_['column_email']      = 'E-Mail';
$_['column_status']     = 'Estado';
$_['column_commission'] = 'Comisión';
$_['column_orders']     = 'No. de Pedidos';
$_['column_total']      = 'Total';
$_['column_action']     = 'Acción';

// Entry
$_['entry_date_start']  = 'Fecha de Inicio:';
$_['entry_date_end']    = 'Fecha de Terminación:';
?>
