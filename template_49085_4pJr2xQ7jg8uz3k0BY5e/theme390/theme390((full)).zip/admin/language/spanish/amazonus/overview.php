<?php
$_['lang_title']                    = 'OpenBay Pro para Amazon US';
$_['lang_heading']                  = 'Resumen Amazon US';
$_['lang_overview']                 = 'Resumen Amazon US';
$_['lang_openbay']                  = 'OpenBay Pro';
$_['lang_heading_settings']         = 'Configuraciones';
$_['lang_heading_account']          = 'Mi cuenta';
$_['lang_heading_links']            = 'Enlaces del artículo';
$_['lang_heading_register']         = 'Registrar';
$_['lang_heading_stock_updates']    = 'actualizaciones del Stock';
$_['lang_heading_saved_listings']   = 'Listas guardadas';