<?php
$_['lang_openbay']                      = 'OpenBay Pro';
$_['lang_page_title']                   = 'OpenBay Pro para eBay';
$_['lang_ebay']                         = 'eBay';
$_['lang_heading']                      = 'Reporte del Stock';
$_['lang_btn_return']                   = 'Regresar';
$_['lang_report_label']                 = 'Reporte por Email';
$_['lang_report_btn']                   = 'Petición';
$_['lang_ajax_load_error']              = 'Lo sentimos, no pudimos extablecer la conexión';
$_['lang_ajax_load_sent']               = 'La petición ha sido enviada';
