<?php
$_['lang_openbay_new']              = 'Crear Nuevo listado';
$_['lang_openbay_edit']             = 'Ver / Editar listado';
$_['lang_openbay_fix']              = 'Arreglar errores';
$_['lang_openbay_processing']       = 'Procesar';

$_['lang_amazonus_saved']           = 'Guardar (no subido)';
$_['lang_amazon_saved']             = 'Guardar (no subido)';
$_['lang_play_pending_new']         = 'Pendiente (nuevo)';
$_['lang_play_pending_updated']     = 'Pendiente (actualizado)';
$_['lang_play_warning']             = 'Mensajes de cuidado';
$_['lang_play_pending_delete']      = 'Borrados pendientes';
$_['lang_play_stock_updating']      = 'Actualización del Stock';

$_['lang_markets']                  = 'Mercados';
$_['lang_bulk_btn']                 = 'eBay subida de volumenes';

$_['lang_marketplace']              = 'Mercados';
$_['lang_status']                   = 'Estatus';
$_['lang_option']                   = 'Opción';