<?php
// Heading
$_['heading_title']     = 'Envío';

// Text
$_['text_install']      = 'Instalar';
$_['text_uninstall']    = 'Desinstalar';

// Column
$_['column_name']       = 'Método de envío';
$_['column_status']     = 'Estatus';
$_['column_sort_order'] = 'Orden de aparición';
$_['column_action']     = 'Acción';

// Error
$_['error_permission']  = 'Cuidado: No tienes permisos para modificar envíos!';
?>
