<?php
// Heading
$_['heading_title']    = 'Módulos';

// Text
$_['text_install']     = 'Instalar';
$_['text_uninstall']   = 'Desinstalar';

// Column
$_['column_name']      = 'Nombre del módulo';
$_['column_action']    = 'Acción';

// Error
$_['error_permission'] = 'Cuidado: No tienes permisos para modificar los módulos!';
?>
