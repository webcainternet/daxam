<?php
//Heading
$_['heading_title']             = 'Zahlung erstatten';

//Text
$_['text_pp_express']           = 'PayPal Expresskasse';
$_['text_current_refunds']      = 'Diese Zahlung wurde bereits erstattet. Der maximale Erstattungsbetrag ist ';

//Button
$_['btn_cancel']                = 'Abbrechen';
$_['btn_refund']                = 'Erstattung zahlen';

//Form entry
$_['entry_transaction_id']      = 'Transaktionsnummer';
$_['entry_full_refund']         = 'Volle Erstattung';
$_['entry_amount']              = 'Betrag';
$_['entry_message']             = 'Nachricht';

//Error
$_['error_partial_amt']         = 'Das Feld Teilbetrag ist ein Pflichtfeld.';
$_['error_data']                = 'Die Anforderung enthält nicht alle notwendigen Daten.';
?>