<?php
// Heading
$_['heading_title']    = 'Aktionsgutschein';

// Text
$_['text_total']       = 'Auftragssummen';
$_['text_success']     = 'Erfolgreich: Aktionsgutschein geändert!';

// Entry
$_['entry_status']     = 'Status:';
$_['entry_sort_order'] = 'Reihenfolge:';

// Error
$_['error_permission'] = 'Warnung: Sie haben keine Berechtigung, um Aktionsgutscheine zu ändern!';
?>