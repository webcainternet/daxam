<?php
// Heading
$_['heading_title']         = 'Bericht Kundenbonuspunkte';

// Column
$_['column_customer']       = 'Name des Kunden';
$_['column_email']          = 'E-Mail';
$_['column_customer_group'] = 'Kundengruppe';
$_['column_status']         = 'Status';
$_['column_points']         = 'Bonuspunkte';
$_['column_orders']         = 'Anzahl Aufträge';
$_['column_total']          = 'Summe';
$_['column_action']         = 'Aktion';

// Entry
$_['entry_date_start']      = 'Startdatum:';
$_['entry_date_end']        = 'Ablaufdatum:';
?>