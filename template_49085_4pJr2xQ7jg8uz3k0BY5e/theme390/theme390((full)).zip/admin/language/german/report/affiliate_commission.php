<?php
// Heading
$_['heading_title']     = 'Bericht Partnerprovision';

// Column
$_['column_affiliate']  = 'Name des Partners';
$_['column_email']      = 'E-Mail';
$_['column_status']     = 'Status';
$_['column_commission'] = 'Provision';
$_['column_orders']     = 'Anzahl Aufträge';
$_['column_total']      = 'Summe';
$_['column_action']     = 'Aktion';

// Entry
$_['entry_date_start']  = 'Startdatum:';
$_['entry_date_end']    = 'Ablaufdatum:';
?>