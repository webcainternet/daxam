<?php
// Text
$_['text_subject']  = '%s - Anforderung Passwort zurücksetzen';
$_['text_greeting'] = 'Ein neues Passwort wurde angefordert für die Verwaltung von %s.';
$_['text_change']   = 'Bitte den Link unten anklicken, um das Passwort zurückzusetzen:';
$_['text_ip']       = 'Die IP-Adresse für diese Anforderung war: %s';
?>