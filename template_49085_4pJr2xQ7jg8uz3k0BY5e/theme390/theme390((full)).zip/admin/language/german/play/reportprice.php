<?php
$_['lang_cancel']                           = 'Abbrechen';
$_['lang_page_title']                       = 'Preisbericht Mitbewerberreport';
$_['lang_column_name']                      = 'Bezeichnung';
$_['lang_column_dispatchto']                = 'Lieferung nach';
$_['lang_column_price_uk']                  = 'Ihr Preis (UK)';
$_['lang_column_price_cheap_uk']            = 'billigster Preis (UK)';
$_['lang_column_price_euro']                = 'Ihr Preis (Europe)';
$_['lang_column_price_cheap_euro']          = 'billigster Preis (Europe)';
$_['lang_column_stock']                     = 'Lagerbestand';
$_['lang_column_product_id']                = 'Artikelnummer';
$_['lang_column_product_type']              = 'Produktart';
$_['lang_no_data_found']                    = 'Keine Preisinformationen gefunden';
$_['lang_created']                          = 'Bericht erstellt: ';
?>