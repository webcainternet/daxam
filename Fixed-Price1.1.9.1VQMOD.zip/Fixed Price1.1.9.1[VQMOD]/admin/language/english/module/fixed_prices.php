<?php
#############################################################################

#############################################################################
// Heading
$_['heading_title']    = 'Fixed Prices';
$_['enable_fixed_prices']    = 'Enable Fixed Prices Module';
$_['text_success']     = 'Success: You have modified module Fixed Prices!';

?>