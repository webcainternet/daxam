<?php

class ControllerModuleFixedPrices extends Controller {
	protected function index($module) {
	 $enable = $this->config->get('fixed_prices');
	
	}
}


?>